-- Bowtie Network v1: server-side foundation. Run in a NEW Supabase project.
-- Referral attribution and inventory are functional data structures; rewards are DISABLED.
create extension if not exists pgcrypto;
create type public.inventory_kind as enum ('new','used');
create type public.referral_status as enum ('submitted','contacted','appointment','delivered','closed','disputed');
create type public.member_role as enum ('member','staff','admin');

create table public.members (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null check (length(trim(display_name)) between 2 and 100),
 referral_code text not null unique check (referral_code ~ '^[A-Z0-9_-]{6,32}$'),
 role public.member_role not null default 'member',
 invited_by uuid references public.members(id),
 created_at timestamptz not null default now()
);
create table public.dealerships (
 id uuid primary key default gen_random_uuid(),
 name text not null unique,
 participates_used boolean not null default true,
 is_subaru_new_source boolean not null default false
);
create unique index one_new_subaru_source on public.dealerships(is_subaru_new_source) where is_subaru_new_source;
create table public.vehicles (
 id uuid primary key default gen_random_uuid(),
 dealer_id uuid not null references public.dealerships(id),
 vin text not null unique,
 stock text not null,
 year int not null check (year between 1990 and 2040),
 make text not null,
 model text not null,
 trim text,
 kind public.inventory_kind not null,
 price numeric(12,2) check (price >= 0),
 miles int check (miles >= 0),
 image_url text,
 vehicle_url text,
 available boolean not null default true,
 gold_bowtie boolean not null default false,
 updated_at timestamptz not null default now(),
 unique(dealer_id,stock)
);
create or replace function public.validate_inventory() returns trigger language plpgsql as $$
begin
 if new.kind='new' and (lower(new.make)<>'subaru' or not exists(select 1 from public.dealerships d where d.id=new.dealer_id and d.is_subaru_new_source)) then
  raise exception 'New inventory restricted to Hicks Family Subaru new Subarus';
 end if;
 if new.kind='used' and not exists(select 1 from public.dealerships d where d.id=new.dealer_id and d.participates_used) then
  raise exception 'Used inventory source not approved';
 end if;
 return new;
end $$;
create trigger validate_inventory_before_write before insert or update on public.vehicles for each row execute function public.validate_inventory();

create table public.referrals (
 id uuid primary key default gen_random_uuid(),
 member_id uuid not null references public.members(id),
 vehicle_id uuid not null references public.vehicles(id),
 -- Buyer contact details must be stored in the approved dealership CRM, not exposed to referrers.
 crm_lead_id text unique,
 status public.referral_status not null default 'submitted',
 submitted_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table public.referral_events (
 id bigint generated always as identity primary key,
 referral_id uuid not null references public.referrals(id),
 actor_id uuid references public.members(id),
 event_type text not null,
 from_status public.referral_status,
 to_status public.referral_status,
 occurred_at timestamptz not null default now()
);
create table public.invites (
 id uuid primary key default gen_random_uuid(),
 created_by uuid not null references public.members(id),
 token_hash text not null unique,
 expires_at timestamptz not null,
 used_by uuid unique references public.members(id),
 used_at timestamptz,
 created_at timestamptz not null default now()
);
-- Accounting tables deliberately contain no insert/update permissions for client roles.
create table public.reward_ledger (
 id uuid primary key default gen_random_uuid(),
 member_id uuid not null references public.members(id),
 referral_id uuid references public.referrals(id),
 points int not null,
 event_type text not null,
 approved_by uuid references public.members(id),
 created_at timestamptz not null default now(),
 constraint rewards_disabled check (false) not valid
);
create table public.check_register (
 id uuid primary key default gen_random_uuid(),
 member_id uuid not null references public.members(id),
 referral_id uuid references public.referrals(id),
 check_number text,
 amount numeric(12,2),
 status text not null default 'disabled',
 created_at timestamptz not null default now(),
 constraint checks_disabled check (false) not valid
);
-- AuthZ: only a trusted backend with service role may write dealership data or referrals.
-- Never expose the Supabase service_role key in browser code.
alter table public.members enable row level security;
alter table public.dealerships enable row level security;
alter table public.vehicles enable row level security;
alter table public.referrals enable row level security;
alter table public.referral_events enable row level security;
alter table public.invites enable row level security;
alter table public.reward_ledger enable row level security;
alter table public.check_register enable row level security;
create policy members_read_self on public.members for select to authenticated using (id=auth.uid());
-- No direct member UPDATE policy: profile edits must use a narrow, authenticated server endpoint.
-- For safety, membership creation and role management must happen through server functions.
create policy dealerships_public_read on public.dealerships for select to anon,authenticated using (true);
create policy vehicles_public_read on public.vehicles for select to anon,authenticated using (available=true);
create policy referrals_member_read on public.referrals for select to authenticated using (member_id=auth.uid());
-- No direct client read access to event audit trail, invites, or financial records.
-- Staff/admin views should be served by backend endpoints that verify roles server-side.
