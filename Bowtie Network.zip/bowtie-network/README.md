Bowtie Network — Rob Polanco Edition
Color palette: royal purple, black, and gold.

# Bowtie Network — Interactive Prototype

A mobile-first, single-file proof of concept for Rob Polanco.

## Open
Open `index.html` in a browser. For share-link testing, serve the folder from a local static server (`python -m http.server 8000`) or deploy to a static host. The demo uses localStorage in that browser; data is not synchronized between devices.

## Features
- Public landing page and Gold Bowtie featured listings
- New Subaru-only and group-wide pre-owned filters
- Search, vehicle details, member-specific share-link previews
- Demo member self-registration and invitation links
- Demo member dashboard and referral activity
- Admin inventory add/update, Gold Bowtie toggles, CSV import, referral pipeline status, invite preview
- Rewards/check register explicitly disabled

## Inventory CSV
Columns: `year,make,model,price,miles,stock,vin,store,type,gold`
- `type`: `new` or `used`
- `gold`: `yes/no`, `true/false`, or `1/0`
- New entries must be Subaru and `store` must be `Hicks Family Subaru`.
- Pre-owned entries may come from participating Hicks/Ed Hicks stores.
- This prototype does **not** connect to any dealer inventory feed. Sample vehicles are fictional.

## Critical production requirements
This is **not production-ready**. It does not have real authentication, role permissions, server-side referral tracking, secure lead capture, inventory synchronization, email/SMS delivery, or payment infrastructure. Admin access is open in the demo; never deploy as an operational portal without a secure backend and authorization. Do not enter real buyer information or sensitive personal data. Replace the sample catalog with an approved inventory feed and comply with dealer data-use policies.

Rewards: Proposed 1 point = $1, but all point accrual, Visa gift-card redemption, and check issuance remain disabled pending dealership legal/compliance review, particularly for referral compensation at a Texas franchised dealership.

## Suggested production stack
Next.js + managed Postgres (e.g. Supabase), server-enforced row-level security, verified email/phone authentication, expiring invitations, immutable attribution and rewards audit logs, dealer inventory feed/API, lead routing to approved CRM, administrative roles, rate limits, bot protection, and consent/privacy policy.

## Phase 2 backend starter (added)
`supabase/schema.sql` provides an initial PostgreSQL schema and restrictive row-level security policies for accounts, dealers, inventory, referrals, invitation records, immutable-style event tracking, and disabled reward/check registers. It is a **starter**, not a deployed backend: no database, authentication, inventory feed, lead capture, or payments have been connected. Do not run it against an existing production database without review. Member profile edits should be implemented through a narrow server endpoint rather than permitting users to change protected columns; production setup should remove or replace the illustrative `members_update_self` policy. Implement server-side auth, invitation redemption, consent, deduplication, CRM integration, auditing, and tests before collecting real customer information.
